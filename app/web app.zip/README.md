This needs to be run on a web server!

Simply copy this directory onto a webserver and open its corresponding address
in a web browser.

I tested this app using chrome, it would be preferable to use this browser when testing, however it should work on other browsers.

Notes on the filtering algorithm that might be useful:
The algorithm im using is affected by the number of films that are uploaded,
the more films there are the more accurate it should become in finding relevant films. With only 45 current movies added it isnt as accurate as desired. 

